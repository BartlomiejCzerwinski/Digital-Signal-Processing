from django.apps import AppConfig


class SignalAndNoiseGenerationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'signal_and_noise_generation'
